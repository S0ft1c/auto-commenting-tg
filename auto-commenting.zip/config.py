# telethon

id = 000 # напишите ваш id в поле без кавычек
hash = '<вот тут напишите ваш hash>'  # напишите сюда ваш hash В КАВЫЧКАХ (любых)
main_channel = '@tttestchanneel'

